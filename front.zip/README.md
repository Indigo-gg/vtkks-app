# Vue 3 + Vite

This template should help get you started developing with Vue 3 in Vite. The template uses Vue 3 `<script setup>` SFCs, check out the [script setup docs](https://v3.vuejs.org/api/sfc-script-setup.html#sfc-script-setup) to learn more.

Learn more about IDE Support for Vue in the [Vue Docs Scaling up Guide](https://vuejs.org/guide/scaling-up/tooling.html#ide-support).



原型图
![img.png](img.png)

link
![pixso_file](https://pixso.cn/app/prototype/DemVP56DNALeaBkEUgtcMQ?isProto=1&pageId=0%3A1&zm=0.552&lp=1&fi=0&hl=0&sa=1&su=1&zt=0)
